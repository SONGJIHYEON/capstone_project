package org.CapstoneProject;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;



public class Nonmember extends JFrame implements ActionListener {
	private JLabel vNonmem1, vNonmem2, vNonmem3, vNonmemNm, vNonmemPh;
	private JTextField xNonmemId, xNonmemNm, xNonmemPh;
//	private JPasswordField xNonmemPwd;
	private String[] div = {"naver.com", "hanmail.com", "nate.com", "gmail.com", "�����Է�"};      
//	   private String[] col1 = {"�μ���", "�μ���ġ"};      
//	   private String[] col2 = {"�μ���", "����"};      
//	   private String[] div = {"������", "�ӽ���", "�����"};      // ������� �޺��ڽ��� ���
	         
//	   private DefaultTableModel model1 = new DefaultTableModel(col1, 0);      
//	   private DefaultTableModel model2 = new DefaultTableModel(col2, 0);      
		         
//	   private JTable eDept, eSpv;      
//	   private JScrollPane scrollpane1, scrollpane2;      
	
	private JButton BtTempId, BtNonConnect;
	private JComboBox<String> CbEmail;
	
	String NONNM, NONPH;
	
	GridBagLayout gbl;
	GridBagConstraints gbc;
	
	public Nonmember(JFrame fr) {
		gbl = new GridBagLayout();
		gbc = new GridBagConstraints(); 
		
		vNonmem1 = new JLabel("��ȸ�� ����");
		vNonmem2 = new JLabel("�ӽ� ID�� �߱� �����ð� ID�� �Է��ϼ���");
		vNonmem3 = new JLabel("������ �̸��� �޴��� ��ȣ�� �Է��ϼ���");
		vNonmemNm = new JLabel("������");
		vNonmemPh = new JLabel("�޴��� ��ȣ");
		
		xNonmemId = new JTextField(20);
		xNonmemNm = new JTextField(20);
		xNonmemPh = new JTextField(20);

		BtTempId = new JButton("�ӽ�ID�߱�");
		BtTempId.setPreferredSize(new Dimension(100, 28));
		BtTempId.addActionListener(this);
		BtNonConnect = new JButton("��ȸ�� ����");
		BtNonConnect.addActionListener(this);
		BtNonConnect.setPreferredSize(new Dimension(100, 28));
		
		NonmemberView();
	}
	
	private void NonmemberView() {
		setExtendedState(MAXIMIZED_BOTH);
		setTitle("ȸ������");


		setLayout(gbl);
		
		gridbagAdd(vNonmemNm, 0, 4, 1, 1);
		gridbagAdd(vNonmemPh, 0, 5, 1, 1);
		gridbagAdd(vNonmem1, 1, 0, 1, 1);
		gridbagAdd(vNonmem2, 1, 1, 1, 1);
		gridbagAdd(vNonmem3, 1, 2, 1, 1);  
//		gridbagAdd(vNonmem4, 0, 3, 1, 1);
	    gridbagAdd(xNonmemId, 1, 3, 1, 1);
	    gridbagAdd(xNonmemNm, 1, 4, 1, 1);
	    gridbagAdd(xNonmemPh, 1, 5, 1, 1);
	    gridbagAdd(BtTempId, 2, 3, 1, 1);
	    gridbagAdd(BtNonConnect, 2, 5, 1, 1);
//	    gridbagAdd(xMemName, 1, 3, 1, 1);
//	    gridbagAdd(vMemBirth, 0, 4, 1, 1);
//	    gridbagAdd(xMemBirth, 1, 4, 1, 1);
//	    gridbagAdd(vMemPhone, 0, 5, 1, 1);
//	    gridbagAdd(xMemPhone, 1, 5, 1, 1);
//	    gridbagAdd(vMemEmail, 0, 6, 1, 1);
//	    gridbagAdd(xMemEmail1, 1, 6, 1, 1);
//	    gridbagAdd(xMemEmail2, 0, 6, 1, 1);
//	    gridbagAdd(CbEmail, 2, 6, 1, 1);
//	    gridbagAdd(vMemAddr1, 0, 7, 1, 1);
//	    gridbagAdd(xMemAddr1, 1, 7, 1, 1);
//	    gridbagAdd(BtSearchAddr, 2, 7, 1, 1);
//	    gridbagAdd(xMemAddr2, 1, 8, 1, 1);
//	    gridbagAdd(vMemAddr2, 2, 8, 1, 1);
//	    gridbagAdd(xMemAddr3, 1, 9, 1, 1);
//	    gridbagAdd(vMemAddr3, 2, 9, 1, 1);
//	    
//
//	    gridbagAdd(BtRegist, 1, 10, 1, 1);
//	    gridbagAdd(BtCancel, 1, 10, 3, 1);
	    

	         
//	    gridbagAdd(scrollpane1, 0, 11, 2, 1);
//	    gridbagAdd(scrollpane2, 2, 11, 2, 1);
//	    gridbagAdd(regist, 0, 12, 1, 1);
//	    gridbagAdd(cancel, 2, 12, 1, 1);
	    
	   
	    setVisible(true);
	}   
	         
	private void gridbagAdd(Component c, int x, int y, int w, int h) {   
		
		gbc.gridx = x;
		gbc.gridy = y; 
		//���� ���� �� gridx, gridy���� 0    
		
		gbc.gridwidth  = w;
		gbc.gridheight = h;
		
		
		gbl.setConstraints(c, gbc); //������Ʈ�� ������Ʈ ��ġ+ũ�� ������ ���� GridBagLayout�� ��ġ   
		
		add(c);   
		
	}   
	
	public class RandomId {
		Random r = new Random();
		int x = (r.nextInt(900000)+100000);
	}
	
	public static void main(String[] args) {   
		new Nonmember(new JFrame());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == BtTempId) {
			RandomId rid = new RandomId();
			JOptionPane.showMessageDialog(null, "�ӽ� ���̵�� " + rid.x + " �Դϴ�");
			String x = Integer.toString(rid.x);
			xNonmemId.setText(x);
		}
		
		if(e.getSource() == BtNonConnect) {
			NONNM = xNonmemNm.getText();
			NONPH = xNonmemPh.getText();
			CustData.initCustData2(NONNM, NONPH);
			CustData.createCust2();
		}
		
	}   
}	

	
			